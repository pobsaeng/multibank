<template src="./treemenu.html"></template>
<script src="./treemenu.js"></script>
<style src="./treemenu.scss" scoped lang="scss"></style>

