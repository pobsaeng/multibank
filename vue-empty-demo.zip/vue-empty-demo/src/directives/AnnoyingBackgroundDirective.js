import Vue from 'vue';

const defaultBackgroundColor = '#86bbff'

export const AnnoyingBackground = {
    bind(el, binding, vnode) {
        const color = binding.expression || defaultBackgroundColor
        if (el) {
            // el.style.backgroundColor = color
            el.style.color = color
        }
    },
    inserted: function (el) {
        // Focus the element
        el.focus()
    }
}

Vue.directive('annoying-background', AnnoyingBackground)