<script >
import Vue from "vue";
import HeaderComponent from "@/composing/header";
const allMix = require("@/models/allMix");

export default {
  mixins: [allMix],

  opt: {
    status: false,
    errMsg: 'Error new!'
  },

  data() {
    return {};
  },
  mounted() {
    this.$nextTick(function(){
      // console.log(this.$options.opt);

      this.dataObj = {id:121211};

    });
  },
  methods: {},
  components: {
    HeaderComponent
  },
  template: `
  <div>
     <HeaderComponent></HeaderComponent>
  </div>
  `
};
</script>