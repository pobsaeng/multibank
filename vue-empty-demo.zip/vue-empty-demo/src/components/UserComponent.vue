<script >
import Vue from "vue";
import { AnnoyingBackground } from '@/directives/AnnoyingBackgroundDirective.js';
const user = require("@/models/user");

export default {
  mixins: [user],
  methods: {
    onLoad() {
      this.onClick();
    }
  },
  mounted() {
    this.user = {
      id: "111111",
      firstName: "OK",
      lastName: "LA",
      fullName: "Henry Oyeah"
    };
  },
  directives: {
    AnnoyingBackground
  },
  template: `
     <div>
      <div><input type="text" v-annoying-background/></div>
      <button @click="onLoad">Clik</button>
    </div>
  `
};
</script>