module.exports = {
    data() {
        return {
            toggleItems: [
                { text: 'one', done: true },
                { text: 'two', done: false }
            ]
        }
    }
}