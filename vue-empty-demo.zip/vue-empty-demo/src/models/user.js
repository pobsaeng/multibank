module.exports = {
    data() {
        return {
            // id: '52230005',
            // firstName: 'Pob',
            // lastName: 'Saengkhunthod',
            // fullName: 'Joe Anta'
            // ,
            user: {
                id: '52230005',
                firstName: 'Pob',
                lastName: 'Saengkhunthod',
                fullName: 'Joe Anta'
            }
        }
    },
    methods: {
        onClick(e) {
            console.log(JSON.stringify(this.user));
        }
    },
    watch: {
        user: function (val, oval) {
            console.log('--------Old Values--------');
            console.log(JSON.stringify(oval));
            console.log('--------New Values--------');
            console.log(JSON.stringify(val));
        }
        // firstName: function(val) {
        //     console.log('watch firstName: ' + val);
        //     this.fullName = val + ' ' + this.lastName
        // },
        // lastName: function(val) {
        //     console.log('watch fullName: ' + val);
        //     this.fullName = this.firstName + ' ' + val
        // }
    }
}