<template>
<div>
    <h2>hghgh</h2>
</div>
</template>

<script>
export default { name: "HeaderComponent" }
</script>