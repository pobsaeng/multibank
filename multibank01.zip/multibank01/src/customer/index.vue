<template src="./customer.component.html"></template>
<script src="./customer.component.js"></script>
<style src="./customer.component.scss" scoped lang="scss"></style>

