<template src="./report.component.html"></template>
<script src="./report.component.js"></script>
<style src="./report.component.scss" scoped lang="scss"></style>

