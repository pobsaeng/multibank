<template src="./customermanagement.component.html"></template>
<script src="./customermanagement.component.js"></script>
<style src="./customermanagement.component.scss" scoped lang="scss"></style>

