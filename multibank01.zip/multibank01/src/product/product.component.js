import Vue from 'vue'

export default {
  name: 'product',
  components: {},
  props: [],
  data() {
    return {
      myData: null
    }
  },
  beforeCreate: function () {
    console.log(this.$appName)
  },
  created() {
    Vue.prototype.$appName = 'My App';

    this.fetchData()
  },
  watch: {
    '$route': 'fetchData'
  },
  methods: {
    fetchData() {
      console.log(this.$route);
    },
    awesomeNoti() {
      this.$toast.success({
        title: 'Message',
        message: 'Hello'
      })
    }
  },
  computed: {

  },
  beforeMount: function () {

  },
  mounted() {

  }
}
