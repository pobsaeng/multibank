import axios from 'axios';

export default {
  name: 'admin',
  components: {},
  props: [],
  data() {
    return {

    }
  },
  computed: {

  },
  mounted() {

  },
  methods: {
    getAPI() {
      const fullPath = this.PATH_SERVER + this.USER_VERBS.findalluser;
      axios.get(fullPath)
        .then(response => {
          console.log(response.data);
        })
        .catch(e => {
          this.errors.push(e)
        })

    },
  }
}
