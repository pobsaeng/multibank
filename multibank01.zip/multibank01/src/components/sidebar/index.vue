<template src="./sidebar.component.html"></template>
<script src="./sidebar.component.js"></script>
<style src="./sidebar.component.scss" scoped lang="scss"></style>

