<template src="./dailyprocess.component.html"></template>
<script src="./dailyprocess.component.js"></script>
<style src="./dailyprocess.component.scss" scoped lang="scss"></style>

