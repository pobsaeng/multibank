package com.multibank.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.multibank.domain.entity.Customer;
import com.multibank.model.json.request.CustomerRequest;
import com.multibank.repository.CustomerRepository;


@RestController
@RequestMapping("/api/customer")
public class CustomerController {
	
	@Autowired
	CustomerRepository customerRepository;
	
	@GetMapping("/findall")
	public ResponseEntity<?> getFindAll() {
		System.out.println("+++findall+++");
		List<Customer> customers = customerRepository.findAll();
		System.out.println(customers);
		return ResponseEntity.ok(customers);
	}

	@PostMapping("/save")
    public Customer addHoliday(@RequestBody CustomerRequest customerRequest) {
		System.out.println(customerRequest);
		Customer customer = new Customer();
		customer.setCustomerID(customerRequest.getCustomerID());
		customer.setAccountName(customerRequest.getAccountName());
		customer.setAccountNumber(customerRequest.getAccountNumber());
		customer.setAccountBranch(customerRequest.getAccountBranch());
		customer.setClientCode(customerRequest.getClientCode());
		customer.setDownloadTime(customerRequest.getDownloadTime());
		customer.setReferenceNumber1(customerRequest.getReferenceNumber1());
		customer.setReferenceNumber2(customerRequest.getReferenceNumber2());
		return customerRepository.save(customer);
    }
}