module.exports = {
    username: "",
    password: "",
    password_retype: "",
    fullname: "",
    email: "",
    department: "",
    ip_address: "",
    items: []
  };
  