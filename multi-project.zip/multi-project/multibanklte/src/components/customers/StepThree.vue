<template>
    <div class="card" style="margin: 3rem">
        <h2>Source Account!</h2>
    </div>
</template>

<script>
    export default {
        props: ['currentStep'],

        methods: {
          canContinue() {
              this.$emit('can-continue', {value: true});
          }
        },

        mounted() {
           this.$emit('can-continue', {value: true});
        }
    }
</script>