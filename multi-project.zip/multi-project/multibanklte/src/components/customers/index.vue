<template>
<div class="row">
  <div class="col-md-12">
    <div class="box box-bay">
    <div class="box-header with-border">
      <h3 class="box-title">Customer</h3>
    </div>
    <div class="box-body">

        <section>
            <div class="col-md-8 col-md-offset-2">
                <HorizontalStepper 
                :steps="demoSteps" 
                @completed-step="completeStep" 
                :top-buttons="true" 
                @active-step="isStepActive" 
                @stepper-finished="alert"></HorizontalStepper>
            </div>
        </section>

      </div>
    </div>
  </div>
</div>
</template>

<script>
import HorizontalStepper from './HorizontalStepper.vue';
    import StepOne from './StepOne.vue';
    import StepTwo from './StepTwo.vue';
    import StepThree from './StepThree.vue';

    export default {
        name: 'customerstep',
        components: {
            HorizontalStepper
        },
        data(){
            return {
                demoSteps: [
                    {
                        icon: 'mail',
                        name: 'first',
                        number: '1',
                        component: StepOne,
                        completed: false
                    },
                    {
                        icon: 'report_problem',
                        name: 'second',
                        number: '2',
                        component: StepTwo,
                        completed: false
                    },
                    {
                        icon: 'announcement',
                        name: 'third',
                        number: '3',
                        component: StepThree,
                        completed: false
                    }
                ],
                activeStep: 0
            }
        },
        methods: {
            completeStep(payload) {
                this.demoSteps.forEach((step) => {
                    if (step.name === payload.name) {
                        step.completed = true;
                    }
                })
            },
            isStepActive(payload) {
                this.demoSteps.forEach((step) => {
                    if (step.name === payload.name) {
                        if(step.completed === true) {
                            step.completed = false;
                        }
                    }
                })
            },
            alert() {
                console.log('end')
            }
        }
    }
</script>