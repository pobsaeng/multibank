<template>
<div class="row">
  <div class="col-md-12">
    <div class="box box-bay">
    <div class="box-header with-border">
      <h3 class="box-title">Customer</h3>
    </div>
    <div class="box-body">

        <div class="row"> 
          <div class="col-md-4">
            <div class="btn-group">
              <div class="input-group add-on">
                <input class="form-control" placeholder="Search" name="srch-term" id="srch-term" type="text">
                <div class="input-group-btn">
                  <button class="btn btn-warning" type="submit" ><i class="glyphicon glyphicon-search"></i></button>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-8">
             <div class="btn-group pull-right">
              <router-link class="nav-link" to="/customerstepper">
                  <button type="button" class="btn btn-warning"><i class="fa fa-plus-square"></i> Add Customer</button>
              </router-link>
            </div>
          </div>
        </div>

        <div class="row top-buffer">
          <div class="col-xs-12">
            <table id="tblUM" class="table table-bordered table-striped table-hover">
              <thead>
              <tr>
                <th>Krungsri Account Number</th>
                <th>Krungsri Account Name</th>
                <th>Customer</th>
                <th>Telephone / Mobile</th>
                <th>Email</th>
                <th></th>
              </tr>
              </thead>
              <tbody>
              <!--:class="{highlight: isRowActive}"-->
              <tr v-for="(customer, index) in listOfcustomers" :id="customer.customer_id" :data-key="index">
                <td>{{customer.accountNumber}}</td>
                <td>{{customer.accountName}}</td>
                <td>{{customer.customerID}}</td>
                <td></td>
                <td></td>
                <td>
                  <i class="fa fa-pencil"></i>
                  <i class="fa fa-trash-o"></i>
                </td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>
</template>

<script>
import axios from "axios";
export default {
  name: "customer",
  data() {
    return {
      url: this.$root.$children[0].paths.server_path,
      verbs: this.$root.$children[0].paths.verbs,
      listOfcustomers: []
    };
  },
  mounted(){
      this.loadAllCustomer();
  },
  methods: {
      loadAllCustomer(){
        console.log("loadAllCustomer!");
        const me = this;
        const url = me.url + me.verbs.customer.findall;
        axios.get(url, {
        method: "GET"
        }).then(response => {
            
            me.listOfcustomers = response.data;
            console.log(me.listOfcustomers);
        }).catch(error => {
            console.log(error);
        });
      }
  }
};
</script>
<style scoped>
.top-buffer {
  margin-top: 10px;
}
</style>