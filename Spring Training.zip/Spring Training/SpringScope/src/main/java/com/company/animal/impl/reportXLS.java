/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.company.animal.impl;

import com.company.animal.Report;

/**
 *
 * @author totoland
 */
public class reportXLS extends Report{

    @Override
    public void createReport() {
        System.out.println("create XLS");
    }
    
}
