/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.company.animal;

/**
 *
 * @author totoland
 */
public interface Animal {
    
    public int getLegs();
    
    public String say();
    
    public boolean canFly();
    
}
