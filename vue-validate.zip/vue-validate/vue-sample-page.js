Vue.config.devtools = true;
Vue.config.debug = true;


new Vue({
    el: '#app',
    data: {
        message: 'Hello Vue.js!'
    }
});