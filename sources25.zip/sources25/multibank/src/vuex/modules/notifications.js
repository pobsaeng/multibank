const state = {
  main: [
    {
      id: 1,
      body: 'Noti 1'
    },
    {
      id: 2,
      body: 'Noti 2'
    }
  ]
}

const mutations = {

}

export default {
  state,
  mutations
}
