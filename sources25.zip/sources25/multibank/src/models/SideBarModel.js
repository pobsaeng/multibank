module.exports = {
  userPrivilege: {
    M_HOME: false,
    M_SYSTEMADMIN: false,
    M_USERMANAGEMENT: false,
    M_BANKBRANCH_MANAGEMENT: false,
    M_HOLIDAY_MANAGEMENT: false,
    M_BANKSIGNATURE_MANAGEMENT: false,
    M_CUSTOMER_MANAGEMENT: false,
    M_CHEQUE_MANAGEMENT: false,
    M_DAILAY_PROCESS: false,
    M_REPORT: false
  }
};
