<template>
<div class="row">
  <div class="col-12">

    <div class="login-box">
      <!-- /.login-logo -->
      <div class="login-box-body">
        <p class="login-box-msg">Sign in to start your session</p>
        <div>

          <div v-if="error" class="alert alert-danger">
            <a class="close" data-dismiss="alert">&times;</a>
            {{ error }}
          </div>

          <div class="form-group has-feedback">
            <input type="text" class="form-control" placeholder="Username" v-model="loginRequest.username">
            <span class="glyphicon glyphicon-user form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" placeholder="Password" v-model="loginRequest.password">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="row">
            <div class="col-xs-12">
              <button type="submit" @click="login" class="btn btn-primary btn-block btn-flat">Sign In</button>
            </div>
            <!-- /.col -->
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

</template>

<script>
import axios from "axios";
import { EventBus } from '@/misc/event-bus.js';
import MenuItemModel from "../models/MenuItemModel.js";


export default {
  name: 'Login',
  data: function () {
    return {
      MenuItemModel: MenuItemModel,
      loginRequest: {
        username: '',
        password: ''
      },
      error: ''
    }
  },
  methods: {
    
    login: function () {
      const me = this;
      const path = me.$root.$children[0].paths.server_path;
      const verbs = me.$root.$children[0].paths.verbs;
      const url = path + verbs.auth.login;

      me.loginRequest.username = me.loginRequest.username.trim();
      me.loginRequest.password = me.loginRequest.password.trim();

      axios({
        method: "post",
        url: url,
        headers: {
          "Content-Type": "application/json"
        },
        data: me.loginRequest
        }).then(function(response) {
          const data = response.data;
          localStorage.accessToken = JSON.stringify(data.token);
          console.log(JSON.stringify(data.token));
          
          EventBus.$emit('isLoggedIn', true);

          me.getMenu(data.menu, function(result){
            localStorage.privilege = JSON.stringify(result);
            EventBus.$emit('slideMenuItems', result);
          });
          
          me.$router.push('/');
          // console.log(data);
        },
        function (response) {
          console.log(response);
        }
      )
    },
    getMenu(values, callback){
      const menu = {}
      for (var key in values) {
        menu[values[key].privilege] = true;
      }
      callback(menu);
    }
  }
}
</script>
