//package com.multibank.baseconfig;
//
//import java.io.IOException;
//import javax.servlet.FilterChain;
//import javax.servlet.ServletException;
//import javax.servlet.ServletRequest;
//import javax.servlet.ServletResponse;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.util.StringUtils;
//import org.springframework.web.filter.GenericFilterBean;
//import org.springframework.web.filter.OncePerRequestFilter;
//
//public class JwtFilter_ extends OncePerRequestFilter {
//
//	@Value("${javatab.token.header}")
//	private String tokenHeader;
//
//	@Autowired
//	private JwtTokenProvider tokenProvider;
//
////	public void doFilter(final ServletRequest req, final ServletResponse res, final FilterChain chain)
////			throws IOException, ServletException {
////
////		final HttpServletRequest request = (HttpServletRequest) req;
////		final HttpServletResponse response = (HttpServletResponse) res;
////		final String authHeader = request.getHeader(this.tokenHeader);
////
////		System.out.println(authHeader);
////		System.out.println(this.tokenHeader);
////		System.out.println("getMethod: " + request.getMethod());
////
////		String jwt = getJwtFromRequest(request);
////
////		if ("OPTIONS".equals(request.getMethod())) {
////			response.setStatus(HttpServletResponse.SC_OK); // status 200
////			chain.doFilter(req, res);
////		} else {
////
////			if (StringUtils.hasText(jwt) && tokenProvider.validateToken(jwt)) {
////				String username = tokenProvider.getUsernameFromToken(jwt);
////				System.out.println("***username: " + username);
////			}
//
//			// if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//			// throw new ServletException("Missing or invalid Authorization header");
//			// }
//			//
//			// final String token = authHeader.substring(7);
//			//
//			// try {
//			// final Claims claims =
//			// Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody();
//			// System.out.println(claims);
//			// request.setAttribute("claims", claims);
//			//
//			// } catch (final SignatureException e) {
//			// throw new ServletException("Invalid token");
//			// }
//			//
//			// chain.doFilter(req, res);
////		}
////	}
//
//	private String getJwtFromRequest(HttpServletRequest request) {
//		String bearerToken = request.getHeader(this.tokenHeader);
//		if (StringUtils.hasText(bearerToken)) {// && bearerToken.startsWith("Bearer ")
//			return bearerToken.substring(7, bearerToken.length());
//		}
//		return null;
//	}
//
//	@Override
//	protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
//			throws ServletException, IOException {
//		final HttpServletRequest request = (HttpServletRequest) req;
//		final HttpServletResponse response = (HttpServletResponse) res;
//		final String authHeader = request.getHeader(this.tokenHeader);
//
//		System.out.println(authHeader);
//		System.out.println(this.tokenHeader);
//		System.out.println("getMethod: " + request.getMethod());
//
//		String jwt = getJwtFromRequest(request);
//
//		if ("OPTIONS".equals(request.getMethod())) {
//			response.setStatus(HttpServletResponse.SC_OK); // status 200
//			chain.doFilter(req, res);
//		} else {
//
//			if (StringUtils.hasText(jwt) && tokenProvider.validateToken(jwt)) {
//				String username = tokenProvider.getUsernameFromToken(jwt);
//				System.out.println("***username: " + username);
//			}
//		}
//		
//	}
//}
