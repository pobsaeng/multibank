package com.multibank.model.json.response;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:apitextresponse.properties")
public class APITextResponse {
	
	@Value(value = "${response.text.success}")
	public String SUCCESS;
	
	@Value(value = "${response.text.data}")
	public String DATA;
	
	@Value(value = "${response.text.message}")
	public String MESSAGE;

}
