package com.multibank.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.multibank.model.json.request.SignUpRequest;
import com.multibank.model.json.response.APITextResponse;

@RestController
@RequestMapping("/api/user")
public class UserController{
	
	@Autowired
	private APITextResponse APITXT;
	
    @GetMapping("/findOne")
    public ResponseEntity<?> getAllUsers() {
    	Map<String, Object> modelMap = new HashMap<String, Object>(3);
    	modelMap.put(APITXT.MESSAGE, "Hellow Message");
    	modelMap.put(APITXT.SUCCESS, true);
    	
    	SignUpRequest rq = new SignUpRequest();
    	rq.setUsername("Kraipob");
    	rq.setEmail("pob@gmail.com");
    	
    	List<SignUpRequest> list = new ArrayList<SignUpRequest>();
    	list.add(rq);
    	
    	modelMap.put(APITXT.DATA, list);
    	
        return ResponseEntity.ok(modelMap);
    }

    @PostMapping("api")
    public ResponseEntity<?> getUserByName(@PathVariable("username") String username) {
        return ResponseEntity.ok("API!");
    }
}
