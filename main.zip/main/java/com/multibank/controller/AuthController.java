package com.multibank.controller;
import com.multibank.baseconfig.JwtTokenProvider;
import com.multibank.model.json.request.LoginRequest;
import com.multibank.model.json.response.JwtAuthenResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/auth")
public class AuthController {

	@Autowired
	JwtTokenProvider tokenProvider;

	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest) {
		String jwt = tokenProvider.generateTokenFromUsername(loginRequest.getUsername());
		System.out.println("[jwt: " + tokenProvider.getUsernameFromToken(jwt) + "]");
		return ResponseEntity.ok(new JwtAuthenResponse(jwt));
	}
}
