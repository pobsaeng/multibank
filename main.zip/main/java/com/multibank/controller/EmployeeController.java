package com.multibank.controller;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.multibank.exception.BaseAPIException;
import com.multibank.model.json.request.SignUpRequest;
import com.multibank.model.json.response.APITextResponse;

@RestController
public class EmployeeController {

	@Autowired
	private APITextResponse APITXT;

	@GetMapping("/error_api")
	public ResponseEntity<?> showMessage() throws BaseAPIException {
		boolean status = true;
		if (status) {
			throw new BaseAPIException("666666");
		}

		Map<String, Object> modelMap = new HashMap<String, Object>(3);
		modelMap.put(APITXT.MESSAGE, "Hellow Message");
		modelMap.put(APITXT.SUCCESS, true);

		SignUpRequest rq = new SignUpRequest();
		rq.setUsername("Kraipob");
		rq.setEmail("pob@gmail.com");

		List<SignUpRequest> list = new ArrayList<SignUpRequest>();
		list.add(rq);

		modelMap.put(APITXT.DATA, list);

		return ResponseEntity.ok(modelMap);
	}
}