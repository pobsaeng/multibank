-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.18-log - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for multibank
CREATE DATABASE IF NOT EXISTS `multibank` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `multibank`;

-- Dumping structure for table multibank.holiday
CREATE TABLE IF NOT EXISTS `holiday` (
  `holiday_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `holiday_name` varchar(200) DEFAULT NULL,
  `holiday_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`holiday_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table multibank.holiday: ~0 rows (approximately)
/*!40000 ALTER TABLE `holiday` DISABLE KEYS */;
INSERT INTO `holiday` (`holiday_id`, `holiday_name`, `holiday_date`) VALUES
	(1, 'Meeting', '2018-08-30 01:51:03');
/*!40000 ALTER TABLE `holiday` ENABLE KEYS */;

-- Dumping structure for table multibank.item
CREATE TABLE IF NOT EXISTS `item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `menu_id` int(11) NOT NULL DEFAULT '0',
  `icon` varchar(255) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL,
  `route_name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`item_id`,`user_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table multibank.item: ~0 rows (approximately)
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
/*!40000 ALTER TABLE `item` ENABLE KEYS */;

-- Dumping structure for table multibank.log_detail
CREATE TABLE IF NOT EXISTS `log_detail` (
  `log_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` text,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table multibank.log_detail: ~0 rows (approximately)
/*!40000 ALTER TABLE `log_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_detail` ENABLE KEYS */;

-- Dumping structure for table multibank.menu
CREATE TABLE IF NOT EXISTS `menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL DEFAULT '0',
  `icon` varchar(50) NOT NULL DEFAULT '0',
  `name` varchar(150) NOT NULL DEFAULT '0',
  `route_name` varchar(50) NOT NULL DEFAULT '0',
  `level` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Dumping data for table multibank.menu: ~6 rows (approximately)
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` (`menu_id`, `type`, `icon`, `name`, `route_name`, `level`) VALUES
	(1, 'tree', 'fa fa-home', 'Home', 'home', '0'),
	(2, 'tree', 'fa fa-database', 'System Admin', 'systemadmin', '0'),
	(7, 'tree', 'fa fa-user', 'Customer Management', 'customermanagement', '0'),
	(8, 'tree', 'fa fa-cube', 'Cheque Management', 'chequemanagement', '0'),
	(9, 'tree', 'fa fa-pencil', 'Daily Process', 'dailyprocess', '0'),
	(10, 'tree', 'fa fa-bars', 'Report', 'report', '0');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;

-- Dumping structure for table multibank.menu_bak
CREATE TABLE IF NOT EXISTS `menu_bak` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL DEFAULT '0',
  `icon` varchar(50) NOT NULL DEFAULT '0',
  `name` varchar(150) NOT NULL DEFAULT '0',
  `route_name` varchar(50) NOT NULL DEFAULT '0',
  `level` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table multibank.menu_bak: ~10 rows (approximately)
/*!40000 ALTER TABLE `menu_bak` DISABLE KEYS */;
INSERT INTO `menu_bak` (`menu_id`, `type`, `icon`, `name`, `route_name`, `level`) VALUES
	(1, 'tree', 'fa fa-home', 'Home', 'home', '0'),
	(2, 'tree', 'fa fa-database', 'System Admin', 'systemadmin', '0'),
	(3, 'item', 'fa fa-circle-o', 'User Management', 'usermanagement', '1'),
	(4, 'item', 'fa fa-circle-o', 'Bank/Branch Management', 'bankbranchmanagement', '1'),
	(5, 'item', 'fa fa-pencil', 'Holiday Management', 'holiday', '1'),
	(6, 'item', 'fa fa-circle-o', 'Bank Signature Management', 'banksignaturemanagement', '1'),
	(7, 'tree', 'fa fa-user', 'Customer Management', 'customermanagement', '0'),
	(8, 'tree', 'fa fa-cube', 'Cheque Management', 'chequemanagement', '0'),
	(9, 'tree', 'fa fa-pencil', 'Daily Process', 'dailyprocess', '0'),
	(10, 'tree', 'fa fa-bars', 'Report', 'report', '0');
/*!40000 ALTER TABLE `menu_bak` ENABLE KEYS */;

-- Dumping structure for table multibank.menu_item
CREATE TABLE IF NOT EXISTS `menu_item` (
  `menu_id` int(11) NOT NULL,
  `sub_menu_id` int(11) NOT NULL,
  PRIMARY KEY (`menu_id`,`sub_menu_id`),
  KEY `FK_menu_item_sub_menu` (`sub_menu_id`),
  CONSTRAINT `FK_menu_item_menu` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`menu_id`),
  CONSTRAINT `FK_menu_item_sub_menu` FOREIGN KEY (`sub_menu_id`) REFERENCES `sub_menu` (`sub_menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table multibank.menu_item: ~4 rows (approximately)
/*!40000 ALTER TABLE `menu_item` DISABLE KEYS */;
INSERT INTO `menu_item` (`menu_id`, `sub_menu_id`) VALUES
	(2, 1),
	(2, 2),
	(2, 3),
	(2, 4);
/*!40000 ALTER TABLE `menu_item` ENABLE KEYS */;

-- Dumping structure for table multibank.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_nb4h0p6txrmfc0xbrd1kglp9t` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table multibank.roles: ~2 rows (approximately)
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `name`) VALUES
	(2, 'ROLE_ADMIN'),
	(1, 'ROLE_USER');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

-- Dumping structure for table multibank.sub_menu
CREATE TABLE IF NOT EXISTS `sub_menu` (
  `sub_menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT '0',
  `icon` varchar(50) NOT NULL DEFAULT '0',
  `name` varchar(150) NOT NULL DEFAULT '0',
  `route_name` varchar(50) NOT NULL DEFAULT '0',
  `level` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sub_menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table multibank.sub_menu: ~4 rows (approximately)
/*!40000 ALTER TABLE `sub_menu` DISABLE KEYS */;
INSERT INTO `sub_menu` (`sub_menu_id`, `menu_id`, `type`, `icon`, `name`, `route_name`, `level`) VALUES
	(1, 2, 'item', 'fa fa-circle-o', 'User Management', 'usermanagement', '1'),
	(2, 4, 'item', 'fa fa-circle-o', 'Bank/Branch Management', 'bankbranchmanagement', '1'),
	(3, 5, 'item', 'fa fa-pencil', 'Holiday Management', 'holiday', '1'),
	(4, 6, 'item', 'fa fa-circle-o', 'Bank Signature Management', 'banksignaturemanagement', '1');
/*!40000 ALTER TABLE `sub_menu` ENABLE KEYS */;

-- Dumping structure for table multibank.users
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(40) NOT NULL,
  `username` varchar(15) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UKr43af9ap4edm43mmtq01oddj6` (`username`),
  UNIQUE KEY `UK6dotkott2kjsp8vw4d0m25fb7` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table multibank.users: ~2 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`user_id`, `fullname`, `username`, `email`, `password`) VALUES
	(4, 'Kraipob Saengkhunthod', '70003017', '17@gmail.com', '$2a$10$iIs8n.Fwm6w4PG3SBVWJFORw2zBUUwlQ22XISYbNUtAsBsswmW.bK'),
	(6, 'Paew', '70003011', 'paew@gmail.com', '$2a$10$UbPzPwYFg7BV8GkSejxORe1svXE9o6qjleXdE64XeC5OFRqFgOFhW');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for table multibank.user_log
CREATE TABLE IF NOT EXISTS `user_log` (
  `user_id` bigint(20) DEFAULT NULL,
  `log_id` bigint(20) DEFAULT NULL,
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table multibank.user_log: ~0 rows (approximately)
/*!40000 ALTER TABLE `user_log` DISABLE KEYS */;
INSERT INTO `user_log` (`user_id`, `log_id`) VALUES
	(1, 1);
/*!40000 ALTER TABLE `user_log` ENABLE KEYS */;

-- Dumping structure for table multibank.user_roles
CREATE TABLE IF NOT EXISTS `user_roles` (
  `user_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_user_roles_role_id` (`role_id`),
  CONSTRAINT `FKh8ciramu9cc9q3qcqiv4ue8a6` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `FKhfh9dx7w3ubf1co1vdev94g3f` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table multibank.user_roles: ~2 rows (approximately)
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` (`user_id`, `role_id`) VALUES
	(4, 1),
	(6, 1);
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
