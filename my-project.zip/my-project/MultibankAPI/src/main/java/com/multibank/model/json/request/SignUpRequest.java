package com.multibank.model.json.request;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.multibank.domain.entity.ListItems;

public class SignUpRequest {
	private Integer user_id;
	private String fullname;
	private String username;
	private String email;
	private String password;
	private Timestamp created_date;
	private Timestamp updated_date;
	private List<ListItems> items = new ArrayList<ListItems>();
	public Integer getUser_id() {
		return user_id;
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Timestamp getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Timestamp created_date) {
		this.created_date = created_date;
	}
	public Timestamp getUpdated_date() {
		return updated_date;
	}
	public void setUpdated_date(Timestamp updated_date) {
		this.updated_date = updated_date;
	}
	public List<ListItems> getItems() {
		return items;
	}
	public void setItems(List<ListItems> items) {
		this.items = items;
	}
	@Override
	public String toString() {
		return "SignUpRequest [user_id=" + user_id + ", fullname=" + fullname + ", username=" + username + ", email="
				+ email + ", password=" + password + ", created_date=" + created_date + ", updated_date=" + updated_date
				+ ", items=" + items + "]";
	}

}
