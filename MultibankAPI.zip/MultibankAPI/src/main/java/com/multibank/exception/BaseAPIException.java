package com.multibank.exception;

public class BaseAPIException extends Exception {

	private String errorMessage;

	public String getErrorMessage() {
		return errorMessage;
	}
	public BaseAPIException(String errorMessage) {
		super(errorMessage);
		this.errorMessage = errorMessage;
	}
	public BaseAPIException() {
		super();
	}
}