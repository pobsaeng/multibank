package com.multibank.exception;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


@ControllerAdvice
public class ExceptionControllerAdvice {
	//Default
//	@ExceptionHandler(Exception.class)
//	public ResponseEntity<ErrorResponse> exceptionHandler(Exception ex) {
//		ErrorResponse error = new ErrorResponse();
//		error.setErrorcode(HttpStatus.INTERNAL_SERVER_ERROR.value());
//		error.setMessage("Please contact your administrator");
//		return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
//	}
	
	@ExceptionHandler(BaseAPIException.class)
	public ResponseEntity<ErrorResponse> exceptionHandler(Exception ex, ServletRequest req) {
		ErrorResponse error = new ErrorResponse();
		error.setErrorcode(HttpStatus.PRECONDITION_FAILED.value());
		error.setMessage(ex.getMessage());
		error.setSuccess(false);
		error.setPath(((HttpServletRequest) req).getServletPath());

		return new ResponseEntity<ErrorResponse>(error, HttpStatus.OK);
	}
}