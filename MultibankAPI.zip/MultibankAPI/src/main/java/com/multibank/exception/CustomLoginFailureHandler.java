package com.multibank.exception;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CustomLoginFailureHandler implements AuthenticationFailureHandler {
	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) throws IOException, ServletException {
		System.out.println("---Login Failure--");
//		response.setStatus(HttpStatus.BAD_REQUEST.value());
//		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
//		response.setCharacterEncoding("UTF-8");
//		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
//		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
//		response.setCharacterEncoding(StandardCharsets.UTF_8.toString());

		//status code = HttpServletResponse.SC_UNAUTHORIZED
		APIException excep = new APIException();
		excep.setError("Username or Password is invalid!");
		excep.setPath(request.getServletPath());
		excep.setMessage(exception.getMessage()); //HttpServletResponse.SC_UNAUTHORIZED
		excep.setStatus(HttpStatus.BAD_REQUEST.value());

		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(excep);
		response.getWriter().write(json);
	}
}