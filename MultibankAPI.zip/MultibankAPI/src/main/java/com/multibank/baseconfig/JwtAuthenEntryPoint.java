package com.multibank.baseconfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Component
public class JwtAuthenEntryPoint implements AuthenticationEntryPoint {

    private static final Logger logger = LoggerFactory.getLogger(JwtAuthenEntryPoint.class);
    @Override
    public void commence(HttpServletRequest request,
                         HttpServletResponse response,
                         AuthenticationException e) throws IOException, ServletException {
    	
        logger.error("Responding with unauthorized error. Message - {}", e.getMessage());
        
        response.setStatus(HttpStatus.BAD_REQUEST.value());
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		response.setCharacterEncoding(StandardCharsets.UTF_8.toString());
        response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Sorry, You're not authorized to access this resource.");
        
        /*Manual Exception return to inside success method of client that request*/
//      APIException excep = new APIException();
//		excep.setError(HttpServletResponse.SC_UNAUTHORIZED + ", Sorry, You're not authorized to access this resource.");
//		excep.setPath(request.getServletPath());
//		excep.setMessage(exception.getMessage()); //HttpServletResponse.SC_UNAUTHORIZED
//		excep.setStatus(HttpStatus.BAD_REQUEST.value());
//
//		ObjectMapper mapper = new ObjectMapper();
//		String json = mapper.writeValueAsString(excep);
//		response.getWriter().write(json);		
    }
}
