<template>
	<full-calendar
	ref="calendar"
	:config="config" 
	:events="events"
	/>
</template>

<script>
import moment from "moment";
export default {
  name: "hello",
  data() {
    return {
      events: [
        // {
        //   title: "test",
        //   allDay: true,
        //   start: moment(),
        //   end: moment().add(1, "d")
        // },
        // {
        //   title: "another test",
        //   start: moment().add(2, "d"),
        //   end: moment()
        //     .add(2, "d")
        //     .add(2, "h")
        // }
      ],
      config: {
        locale: "th",
        defaultView: "month",

        events(start, end, timezone, callback) {
          console.log("events callback!");
          callback([
            {
              title: "*Team Work*",
              // allDay: true,
              start: moment(4, "d"),
              end: moment()
                .add(2, "d")
                .add(2, "h")
            },
            {
              title: "#Vue Sharing",
              start: moment().add(4, "d"),
              end: moment()
                .add(3, "d")
                .add(3, "h")
            }
          ]);
        },
        eventRender: function(event, element) {
          console.log("eventRender!");
        },
        eventAfterRender(event) {
          console.log("eventafterRender!");
        },
        select(start, end, jsEvent, view) {
          console.log("select!");
          console.log(start);
          console.log(end);
          console.log(jsEvent);
          console.log(view);
        },
        selectAllow() {
          console.log("selectAllow!");
        },
        selectable() {
          console.log("selectable!");
        }
      }
    };
  },
  methods: {}
};
</script>
