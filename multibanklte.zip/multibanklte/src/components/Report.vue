<template>
<div class="row">
  <div class="col-md-12">
    <!-- general form elements -->
    <div class="box box-bay">
      <div class="box-header with-border">
        <h3 class="box-title">Report</h3>
      </div>

    </div>
  </div>
</div>
</template>

<script>
export default {
  name: "report",
  data() {
    return {};
  }
};
</script>