<template>
  <div id="app">
    <div class="wrapper">
      <va-navibar></va-navibar>
      <va-slider></va-slider>
      <va-content-wrap></va-content-wrap>
    </div>
  </div>
</template>

<script>
import VANaviBar from "./template/NaviBar.vue";
import VASlider from "./template/SideBar.vue";
import VAContentWrap from "./template/ContentWrap.vue";

export default {
  name: "App",
  data() {
    return {
      loggedIn: false
    }
  },
  created() {},
  components: {
    "va-content-wrap": VAContentWrap,
    "va-navibar": VANaviBar,
    "va-slider": VASlider
  }
};
</script>

<style scroped>
@import './assets/customize/AdminLTE.css';
@import './assets/customize/main.css';
</style>
