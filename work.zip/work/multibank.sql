﻿# HeidiSQL Dump 
#
# --------------------------------------------------------
# Host:                         10.100.60.178
# Database:                     multibank
# Server version:               5.6.22-log
# Server OS:                    Win64
# Target compatibility:         ANSI SQL
# HeidiSQL version:             4.0
# Date/time:                    2018-09-12 17:52:54
# --------------------------------------------------------

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI,NO_BACKSLASH_ESCAPES';*/
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;*/


#
# Database structure for database 'multibank'
#

CREATE DATABASE /*!32312 IF NOT EXISTS*/ "multibank" /*!40100 DEFAULT CHARACTER SET utf8 */;

USE "multibank";


#
# Table structure for table 'holiday'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "holiday" (
  "holiday_id" bigint(20) NOT NULL AUTO_INCREMENT,
  "holiday_name" varchar(200) DEFAULT NULL,
  "holiday_date" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("holiday_id")
) AUTO_INCREMENT=2;



#
# Dumping data for table 'holiday'
#

# No data found.



#
# Table structure for table 'items'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "items" (
  "item_id" int(11) NOT NULL AUTO_INCREMENT,
  "user_item_id" int(11) DEFAULT NULL,
  "item_name" varchar(200) NOT NULL,
  PRIMARY KEY ("item_id")
) AUTO_INCREMENT=12;



#
# Dumping data for table 'items'
#

LOCK TABLES "items" WRITE;
/*!40000 ALTER TABLE "items" DISABLE KEYS;*/
REPLACE INTO "items" ("item_id", "user_item_id", "item_name") VALUES
	(8,2,'Holiday Management');
REPLACE INTO "items" ("item_id", "user_item_id", "item_name") VALUES
	(9,2,'Bank Signature Management');
REPLACE INTO "items" ("item_id", "user_item_id", "item_name") VALUES
	(10,2,'Home');
REPLACE INTO "items" ("item_id", "user_item_id", "item_name") VALUES
	(11,2,'System Admin');
/*!40000 ALTER TABLE "items" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'log_detail'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "log_detail" (
  "log_id" bigint(20) NOT NULL AUTO_INCREMENT,
  "description" text,
  "last_update" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY ("log_id")
);



#
# Dumping data for table 'log_detail'
#

# No data found.



#
# Table structure for table 'roles'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "roles" (
  "id" bigint(11) NOT NULL AUTO_INCREMENT,
  "name" varchar(60) NOT NULL,
  PRIMARY KEY ("id"),
  UNIQUE KEY "UK_nb4h0p6txrmfc0xbrd1kglp9t" ("name")
) AUTO_INCREMENT=3;



#
# Dumping data for table 'roles'
#

LOCK TABLES "roles" WRITE;
/*!40000 ALTER TABLE "roles" DISABLE KEYS;*/
REPLACE INTO "roles" ("id", "name") VALUES
	('2','ROLE_ADMIN');
REPLACE INTO "roles" ("id", "name") VALUES
	('1','ROLE_USER');
/*!40000 ALTER TABLE "roles" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'users'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "users" (
  "id" bigint(20) NOT NULL AUTO_INCREMENT,
  "fullname" varchar(40) NOT NULL,
  "username" varchar(15) NOT NULL,
  "email" varchar(40) NOT NULL,
  "password" varchar(100) NOT NULL,
  "created_date" datetime DEFAULT NULL,
  "updated_date" datetime DEFAULT NULL,
  PRIMARY KEY ("id"),
  UNIQUE KEY "UKr43af9ap4edm43mmtq01oddj6" ("username"),
  UNIQUE KEY "UK6dotkott2kjsp8vw4d0m25fb7" ("email")
) AUTO_INCREMENT=9;



#
# Dumping data for table 'users'
#

LOCK TABLES "users" WRITE;
/*!40000 ALTER TABLE "users" DISABLE KEYS;*/
REPLACE INTO "users" ("id", "fullname", "username", "email", "password", "created_date", "updated_date") VALUES
	('1','Kraipob','Saengkhunthod','pobsaeng@gmail.com','$2a$10$BRb5vH97f3vO8ucElmWBmeHvwDgfO08uswfgAuQ/UFMYa31wVDMlu',NULL,NULL);
REPLACE INTO "users" ("id", "fullname", "username", "email", "password", "created_date", "updated_date") VALUES
	('2','John','john','john@gmail.com','$2a$10$BRb5vH97f3vO8ucElmWBmeHvwDgfO08uswfgAuQ/UFMYa31wVDMlu',NULL,NULL);
REPLACE INTO "users" ("id", "fullname", "username", "email", "password", "created_date", "updated_date") VALUES
	('8','Jane','jane@gmail.com','jane@gmail.com','$2a$10$FZZGVcJcOL0Ygje1NKdsjOmcomFgv1i6L.RgtRyitD9Ftof8veghW',NULL,NULL);
/*!40000 ALTER TABLE "users" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'user_items'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "user_items" (
  "user_item_id" int(11) NOT NULL AUTO_INCREMENT,
  "user_id" int(11) NOT NULL,
  "created_date" timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_date" timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("user_item_id")
) AUTO_INCREMENT=3;



#
# Dumping data for table 'user_items'
#

LOCK TABLES "user_items" WRITE;
/*!40000 ALTER TABLE "user_items" DISABLE KEYS;*/
REPLACE INTO "user_items" ("user_item_id", "user_id", "created_date", "updated_date") VALUES
	(2,8,NULL,NULL);
/*!40000 ALTER TABLE "user_items" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'user_log'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "user_log" (
  "user_id" bigint(20) DEFAULT NULL,
  "log_id" bigint(20) DEFAULT NULL,
  KEY "user_id" ("user_id")
);



#
# Dumping data for table 'user_log'
#

# No data found.



#
# Table structure for table 'user_roles'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "user_roles" (
  "user_id" bigint(20) NOT NULL,
  "role_id" bigint(20) NOT NULL,
  PRIMARY KEY ("user_id","role_id"),
  KEY "fk_user_roles_role_id" ("role_id"),
  CONSTRAINT "FKh8ciramu9cc9q3qcqiv4ue8a6" FOREIGN KEY ("role_id") REFERENCES "roles" ("id"),
  CONSTRAINT "FKhfh9dx7w3ubf1co1vdev94g3f" FOREIGN KEY ("user_id") REFERENCES "users" ("id")
);



#
# Dumping data for table 'user_roles'
#

LOCK TABLES "user_roles" WRITE;
/*!40000 ALTER TABLE "user_roles" DISABLE KEYS;*/
REPLACE INTO "user_roles" ("user_id", "role_id") VALUES
	('1','1');
REPLACE INTO "user_roles" ("user_id", "role_id") VALUES
	('2','2');
/*!40000 ALTER TABLE "user_roles" ENABLE KEYS;*/
UNLOCK TABLES;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE;*/
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;*/
