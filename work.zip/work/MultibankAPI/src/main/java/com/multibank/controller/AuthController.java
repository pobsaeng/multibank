package com.multibank.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.multibank.baseconfig.JwtTokenProvider;
import com.multibank.domain.entity.Items;
import com.multibank.domain.entity.MenuItems;
import com.multibank.domain.entity.User;
import com.multibank.domain.entity.UserItems;
import com.multibank.exception.APIException;
import com.multibank.model.json.request.LoginRequest;
import com.multibank.model.json.request.SignUpRequest;
import com.multibank.model.json.response.JwtAuthenResponse;
import com.multibank.repository.ItemsRepository;
import com.multibank.repository.RoleRepository;
import com.multibank.repository.UserItemsRepository;
import com.multibank.repository.UserRepository;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	UserItemsRepository userItemsRepository;
	
	@Autowired
	ItemsRepository itemsRepository;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	JwtTokenProvider tokenProvider;
	
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest, HttpServletRequest request) throws APIException{
		System.out.println("--------AuthController[signin]------------");
		if(loginRequest.getUsername().equals("")) {
			throw new APIException(
					"Usernae is require!",
					HttpServletResponse.SC_UNAUTHORIZED,
					HttpStatus.BAD_REQUEST.value(),
					request.getServletPath(),
					new Timestamp(System.currentTimeMillis())
					);
			
		}else if(loginRequest.getPassword().equals("")) {
			throw new APIException(
					"Password is require!",
					HttpServletResponse.SC_UNAUTHORIZED,
					HttpStatus.BAD_REQUEST.value(),
					request.getServletPath(),
					new Timestamp(System.currentTimeMillis())
					);
		}
		Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));
		SecurityContextHolder.getContext().setAuthentication(authentication);

		String jwt = tokenProvider.generateToken(authentication);
		System.out.println("[jwt: " + tokenProvider.getUserIdFromJWT(jwt) + "]");
		return ResponseEntity.ok(new JwtAuthenResponse(jwt));
	}

	@PostMapping("/signup")
	@Transactional
	public ResponseEntity<?> registerUser(@RequestBody SignUpRequest signUpRequest) {
		System.out.println("+--------signup--------+");
		
		System.out.println(signUpRequest);
		
//		if (userRepository.existsByUsername(signUpRequest.getUsername())) {
//			System.out.println("+---existsByUsername----+");
//			return new ResponseEntity(new APIResponse(false, "Username is already taken!"), HttpStatus.BAD_REQUEST);
//		}
//
//		if (userRepository.existsByEmail(signUpRequest.getEmail())) {
//			return new ResponseEntity(new APIResponse(false, "Email Address already in use!"), HttpStatus.BAD_REQUEST);
//		}
//
//		// Creating user's account
		User user = new User();
		user.setId(signUpRequest.getUser_id());
		user.setFullname(signUpRequest.getFullname());
		user.setEmail(signUpRequest.getEmail());
		user.setUsername(signUpRequest.getUsername());
		user.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));
		user.setUpdated_date(null);
		user.setCreated_date(null);
		User u = userRepository.save(user);
		
		System.out.println(u);
		
		UserItems userItems = new UserItems();
		userItems.setUser_id(u.getId());
		UserItems uitems = userItemsRepository.save(userItems);
		System.out.println(uitems);
		System.out.println("------------------------------------");
		
		List<MenuItems> listItems = signUpRequest.getItems();
		for (MenuItems menuItems : listItems) {
			Items items = new Items();
			items.setUser_item_id(uitems.getUser_item_id());
			items.setItem_name(menuItems.getText());
			itemsRepository.saveAndFlush(items);
		}
		
//		List<Items> listTM = new ArrayList<>();
//		for (int i = 0; i < listItems.size(); i++) {
//			Items items = new Items();
//			items.setUser_item_id(uitems.getUser_item_id());
//			items.setItem_name(listItems.get(i).getText());
//			listTM.add(items);
//			itemsRepository.saveAll(listTM);
//		}
		
		
//		Role userRole = roleRepository.findByName(RoleName.ROLE_USER).orElseThrow(() -> new AppException("User Role not set."));
//		user.setRoles(Collections.singleton(userRole));
//
//		User result = userRepository.save(user);
//		
//		System.out.println("+--------------start---------------+");
//		URI location = ServletUriComponentsBuilder.fromCurrentContextPath().path("/users/{username}").buildAndExpand(result.getUsername()).toUri();
//		System.out.println(location.getUserInfo());
//		System.out.println(location.getPath());
//		System.out.println(result);
//		System.out.println("+-----------------------------+");

		return ResponseEntity.ok(signUpRequest);
	}
}
