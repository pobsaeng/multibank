package com.multibank.envconfig;

public interface BasedCofig {
	void setup();
}
