package com.multibank.domain.entity;

import javax.persistence.*;

@Entity
@Table(name = "items")
public class Items {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer item_id;
	private Integer user_item_id;
	private String item_name;
	public Integer getItem_id() {
		return item_id;
	}
	public void setItem_id(Integer item_id) {
		this.item_id = item_id;
	}
	public Integer getUser_item_id() {
		return user_item_id;
	}
	public void setUser_item_id(Integer user_item_id) {
		this.user_item_id = user_item_id;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
//	@Override
//	public String toString() {
//		return "Items [item_id=" + item_id + ", user_item_id=" + user_item_id + ", item_name=" + item_name + "]";
//	}
//		
}
