Vue.component('home', {
    template: `
  <div>
  	<div>Home</div>
  </div>
  `,
    data: function () {
        return {
            user: null
        }
    },
    mounted() {
        const url = "http://localhost/vue-singlepage/assets/user.json";
        axios.get(url).then(response => {
            this.user = response.data;
            console.log(this.user);
        });
    }
})