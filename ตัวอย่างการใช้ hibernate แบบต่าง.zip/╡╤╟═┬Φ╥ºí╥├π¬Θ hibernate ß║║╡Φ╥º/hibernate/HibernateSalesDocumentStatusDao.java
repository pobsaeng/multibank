package com.ie.icon.dao.hibernate;

import com.ie.icon.dao.SalesDocumentStatusDao;

public class HibernateSalesDocumentStatusDao extends HibernateCommonDao implements SalesDocumentStatusDao{

}
