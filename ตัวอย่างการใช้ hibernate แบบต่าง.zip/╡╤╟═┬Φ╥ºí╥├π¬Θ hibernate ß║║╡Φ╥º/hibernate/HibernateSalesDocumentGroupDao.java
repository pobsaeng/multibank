package com.ie.icon.dao.hibernate;

import com.ie.icon.dao.SalesDocumentGroupDao;

public class HibernateSalesDocumentGroupDao extends HibernateCommonDao implements SalesDocumentGroupDao{

}
