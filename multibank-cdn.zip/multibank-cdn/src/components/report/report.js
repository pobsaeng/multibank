Vue.component("report", {
  template: `
  <div class="row">
    <div class="col-md-12">
      <!-- general form elements -->
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Report</h3>
        </div>

      </div>
    </div>
  </div>
  `,
  data: function() {
    return {};
  },
  methods: {},
  mounted() {
    console.log("mounted!");
  }
});
