Vue.component("home", {
  template: `
  <div>
    <div class="row">
      <div class="col-md-12">
        <div class="box box-warning">
          <div class="box-header">
            <h3 class="box-title">Home Page.</h3>
          </div>
          <div class="box-body">

            <div class="callout callout-info">
              <h4>Reminder!</h4>
              Instructions for how to use modals are available on the
              <a href="http://getbootstrap.com/javascript/#modals">Bootstrap documentation</a>
            </div>
            
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-12">
          
        <div class="box box-primary">
        <div class="box-header">
          <h3 class="box-title">Task.</h3>
        </div>
        <div class="box-body"></div>
        </div> 

      </div>
    </div>

  </div>
  `,
  data: function() {
    return {};
  },
  methods: {},
  mounted() {
    console.log("mounted!");
  }
});
