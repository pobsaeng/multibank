Vue.component("confirm-modal", {
    props: ['msg', 'head'],
  template: `
   <div id="confirm-modal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
      <div class="modal-content">
      <div class="modal-header">
            <slot name="header"><b>{{head}}</b></slot>
            <button @click="$emit('close')" type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
          </div>

          <div class="modal-body">
            <slot name="body">{{msg}}</slot>
          </div>

          <div class="modal-footer">
            <slot name="footer">
            <button type="button" @click="$emit('close')" class="btn btn-primary btn-sm" data-dismiss="modal">Save</button>
            <button type="button" @click="$emit('close')" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
            </slot>
          </div>
      </div>
  </div>
  </div>
  `,
  data: function() {
    return {};
  },
  mounted() {}
});
