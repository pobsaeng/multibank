package com.multibank.domain.entity;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_items")
public class UserItems {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer user_item_id;

	private Integer user_id;
	
	private Timestamp created_date;
	private Timestamp updated_date;
	
	public Integer getUser_item_id() {
		return user_item_id;
	}
	public void setUser_item_id(Integer user_item_id) {
		this.user_item_id = user_item_id;
	}
	public Integer getUser_id() {
		return user_id;
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	public Timestamp getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Timestamp created_date) {
		this.created_date = created_date;
	}
	public Timestamp getUpdated_date() {
		return updated_date;
	}
	public void setUpdated_date(Timestamp updated_date) {
		this.updated_date = updated_date;
	}
//	@Override
//	public String toString() {
//		return "UserItems [user_item_id=" + user_item_id + ", user_id=" + user_id + ", created_date=" + created_date
//				+ ", updated_date=" + updated_date + "]";
//	}

	
	
}
