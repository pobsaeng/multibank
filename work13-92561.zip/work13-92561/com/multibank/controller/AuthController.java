package com.multibank.controller;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.multibank.baseconfig.JwtTokenProvider;
import com.multibank.domain.entity.Items;
import com.multibank.domain.entity.MenuItems;
import com.multibank.domain.entity.Role;
import com.multibank.domain.entity.RoleName;
import com.multibank.domain.entity.User;
import com.multibank.domain.entity.UserItems;
import com.multibank.exception.APIException;
import com.multibank.exception.AppException;
import com.multibank.model.json.request.LoginRequest;
import com.multibank.model.json.request.SignUpRequest;
import com.multibank.model.json.response.JwtAuthenResponse;
import com.multibank.repository.ItemsRepository;
import com.multibank.repository.RoleRepository;
import com.multibank.repository.UserItemsRepository;
import com.multibank.repository.UserRepository;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	UserItemsRepository userItemsRepository;
	
	@Autowired
	ItemsRepository itemsRepository;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	JwtTokenProvider tokenProvider;
	
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest, HttpServletRequest request) throws APIException{
		System.out.println("--------AuthController[signin]------------");
		if(loginRequest.getUsername().equals("")) {
			throw new APIException(
					"Usernae is require!",
					HttpServletResponse.SC_UNAUTHORIZED,
					HttpStatus.BAD_REQUEST.value(),
					request.getServletPath(),
					new Timestamp(System.currentTimeMillis())
					);
			
		}else if(loginRequest.getPassword().equals("")) {
			throw new APIException(
					"Password is require!",
					HttpServletResponse.SC_UNAUTHORIZED,
					HttpStatus.BAD_REQUEST.value(),
					request.getServletPath(),
					new Timestamp(System.currentTimeMillis())
					);
		}
		Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));
		SecurityContextHolder.getContext().setAuthentication(authentication);

		String jwt = tokenProvider.generateToken(authentication);
		System.out.println("[jwt: " + tokenProvider.getUserIdFromJWT(jwt) + "]");
		return ResponseEntity.ok(new JwtAuthenResponse(jwt));
	}
	@PostMapping("/signup")
	public ResponseEntity<?> registerUser(@RequestBody SignUpRequest signUpRequest) {
		System.out.println("+--------signup--------+");

		User user = new User();
		user.setId(signUpRequest.getUser_id());
		user.setFullname(signUpRequest.getFullname());
		user.setEmail(signUpRequest.getEmail());
		user.setUsername(signUpRequest.getUsername());
		user.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));
		user.setUpdated_date(null);
		user.setCreated_date(null);
		
		Role userRole = roleRepository.findByName(RoleName.ROLE_USER).orElseThrow(() -> new AppException("User Role not set."));
		user.setRoles(Collections.singleton(userRole));
		User sUser = userRepository.save(user);
		
		UserItems userItems = new UserItems();
		userItems.setUser_id(sUser.getId());
		UserItems uitems = userItemsRepository.save(userItems);
		
		List<MenuItems> listItems = signUpRequest.getItems();
		for (MenuItems menuItems : listItems) {
			Items items = new Items();
			items.setUser_item_id(uitems.getUser_item_id());
			items.setItem_name(menuItems.getText());
			itemsRepository.save(items);
		}

		return ResponseEntity.ok(signUpRequest);
	}
	@GetMapping("/findall")
    public ResponseEntity<?> getFindAll() {
		Map<String, Object> map = new HashMap<>();
		List<User> users = userRepository.findAll();
    	map.put("users", users);
		return new ResponseEntity(map, HttpStatus.OK);
    }
	@GetMapping("/finbyuser/{user_id}")
    public ResponseEntity<?> getFinByUser(@PathVariable("user_id") Integer user_id) {
		System.out.println("user_id: " + user_id);
		Map<String, Object> mResult = new HashMap<>();
		Map<String, Object> map = new HashMap<>();
		
    	Optional<User> users = userRepository.findById(user_id);
    	UserItems userItems = userItemsRepository.findUserById(users.get().getId());
    	List<Items> listItems = itemsRepository.findUserItemById(userItems.getUser_item_id());
    	map.put("users", users);
    	map.put("Items", listItems);
    	
    	mResult.put("results", map);
		return new ResponseEntity(mResult, HttpStatus.OK);
    }
}
