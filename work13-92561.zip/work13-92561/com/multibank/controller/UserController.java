package com.multibank.controller;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import com.multibank.baseconfig.CurrentUser;
import com.multibank.baseconfig.UserPrincipal;
import com.multibank.domain.entity.User;
import com.multibank.util.AppConstants;


@RestController
@RequestMapping("/api/user")
public class UserController {

    @GetMapping
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> getPolls(@CurrentUser UserPrincipal currentUser,
                                                @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
    	System.out.println(currentUser);
    	System.out.println("page: " + page + ", size: " +size);
		return new ResponseEntity("This is paging & hasRole('USER')", HttpStatus.OK);
    }

    @PostMapping("allpoll")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> createPoll() {
    	return new ResponseEntity("I have a hasRole('USER')", HttpStatus.OK);
    }
    
    
    @PostMapping("currentuser")
    public ResponseEntity<?> getCurrentUser() {
    	System.out.println("---getCurrentUser---");
//    	UserPrincipal user = (UserPrincipal)SecurityContextHolder.getContext().getAuthentication().getPrincipal();         

    	  String username = "";
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
		} else {
			username = principal.toString();
		}

    	return new ResponseEntity(username, HttpStatus.OK);
    }
}