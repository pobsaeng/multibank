package com.multibank.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.multibank.domain.entity.Items;

@Repository
public interface ItemsRepository extends JpaRepository<Items, Integer>{
	@Query(value = "SELECT tms FROM Items tms WHERE tms.user_item_id=:user_item_id")
	List<Items> findUserItemById(@Param("user_item_id") Integer user_item_id);
}
