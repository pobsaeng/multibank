package com.multibank.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.multibank.domain.entity.UserItems;

@Repository
public interface UserItemsRepository extends JpaRepository<UserItems, Integer> {
	@Query(value = "SELECT utms FROM UserItems utms WHERE utms.user_id=:user_id")
	UserItems findUserById(@Param("user_id") Integer user_id);
	
}
