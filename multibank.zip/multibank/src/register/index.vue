<template src="./register.component.html"></template>
<script src="./register.component.js"></script>
<style src="./register.component.scss" scoped lang="scss"></style>

