import Vue from 'vue'
import axios from 'axios';
// import * as createDemo from '@/models/user.model'
// import {CookiesManager as cm1} from './modules/CookiesManager'

export default {
  name: 'register',
  components: {},
  props: [],
  data() {
    return {
      user: {}
    }
  },
  computed: {

  },
  mounted() {

  },
  methods: {
    onCancel() {
      alert("sdf");

      this.$refs.registerForm.preventDefault();

      return false;
    },
    onSubmmit(e) {
      console.log(this.$root.$children[0].getFormValues());
    },
    onCreateUser(event) {
      const me = this;
      //@submit.prevent="onCreateUser"
      const USER_TOKEN = localStorage.getItem("jwtToken");
      const srvpath = this.SERVER_PATH + this.USER_VERBS.register;
      const params = this.$root.$children[0].getFormValues(event);
      this.$root.$children[0].removeElement(params, "cpassword");
      params.id = null;
      console.log(params);

      const pm = {
        id: null,
        name: 'User4',
        username: 'user4@krungsri.com',
        password: '123456',
        email: 'user4@krungsri.com'
      }
      console.log(pm);

      axios({
        method: 'post',
        url: srvpath,
        headers: {
          'Content-Type': 'application/json',
          "Authorization": "Bearer " + USER_TOKEN
        },
        data: params
      }).then(function (response) {
        console.log("----------Success---------");
        console.log(response.data);
        me.$swal({
          type: "warning",
          title: "Alert Message!",
          text: response.data.message
        });

      }).catch(error => {
        console.log("----------Error---------");
        console.log(error.response);
        me.$swal({
          type: "error",
          title: "Error Message!",
          text: error.response.data.message
        });
      });

    },
    getCreateUser(event) {
      const me = this;
      const USER_TOKEN = localStorage.getItem("jwtToken");
      const srvpath = this.SERVER_PATH + this.USER_VERBS.register;
      const u = this.$root.$children[0].getFormValues(event);
      console.log(u);

      const params = {
        id: null,
        name: 'User2',
        username: 'user3@krungsri.com',
        password: '123456',
        email: 'user3@krungsri.com'
      }
      axios({
        method: 'post',
        url: srvpath,
        headers: {
          'Content-Type': 'application/json',
          "Authorization": "Bearer " + USER_TOKEN
        },
        data: params
      }).then(function (response) {
        console.log("----------Success---------");
        console.log(response.data);
        me.$swal({
          type: "warning",
          title: "Alert Message!",
          text: response.data.message
        });

      }).catch(error => {
        console.log("----------Error---------");
        console.log(error.response);
        me.$swal({
          type: "warning",
          title: "Alert Message!",
          text: error.response.message
        });
      });
    }
  }
}
