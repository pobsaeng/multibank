import axios from 'axios';

export default {
  name: 'register',
  components: {},
  props: [],
  data() {
    return {

    }
  },
  computed: {

  },
  mounted() {

  },
  methods: {
    getCreateUser() {
      const USER_TOKEN = localStorage.getItem("jwtToken");

      const srvpath = this.SERVER_PATH + this.USER_VERBS.register;
      console.log(srvpath);

      const params = {
        id: null,
        name: 'User2',
        username: 'user3@krungsri.com',
        password: '123456',
        email: 'user3@krungsri.com'
      }
      axios({
        method: 'post',
        url: srvpath,
        headers: {
          'Content-Type': 'application/json',
          "Authorization": "Bearer " + USER_TOKEN
        },
        data: params
      }).then(function (response) {
        console.log("----------Success---------");
        console.log(response.data);

      }).catch(error => {
        console.log("----------Error---------");
        console.log(error.response);
      });
    }
  }
}
