<template>
  <div id="app">
    <navbar></navbar>
    <!--router render here-->
    <!--<sidebar></sidebar>-->

    <div class="container-fluid">
    <div class="row">
        <div class="col"><router-view/></div>
    </div>
</div>
  </div>
</template>

<script>
import navbar from '@/components/navbar/index'
// import sidebar from '@/components/sidebar/index'
export default {
  name: 'App',
  components: { navbar }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

html {
    font-size: 14px;
}
</style>
