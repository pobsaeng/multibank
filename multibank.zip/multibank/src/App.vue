<template>
  <div id="app">
    <navbar></navbar>
    <!--router render here-->
    <!--<sidebar></sidebar>-->
    <treemenu></treemenu>

    <div class="container-fluid">
    <div class="row">
        <div class="col"><router-view/></div>
    </div>
</div>
  </div>
</template>

<script>
import navbar from '@/components/navbar/index'
import PathConfig from '@/assets/store/server/server-path.json'
import treemenu from '@/treemenu/index'
// import sidebar from '@/components/sidebar/index'
export default {
  name: 'App',
   methods: {
    getFormValues: function(){
      const tags = event.target.elements;
      const rowData = {};
      var att = '';
      const user = {};

      for (let i = 0; i < tags.length; i++) {
        att = '';
        if (tags[i].nodeName == 'INPUT') {
          att = tags[i].attributes.name.value;
          user[att] = tags[i].value;
        }
      }
      return user;
    },
    removeElement(_object, vals){
      delete _object[vals];
      return _object;
    }
  },
  components: { navbar, treemenu }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

html {
    font-size: 14px;
}
</style>
