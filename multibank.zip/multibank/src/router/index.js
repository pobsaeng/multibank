import Vue from 'vue'
import Router from 'vue-router'

import welcome from '@/components/welcome'
import home from '@/home/index'
import admin from '@/admin/index'
import chequemanagement from '@/chequemanagement/index'
import customermanagement from '@/customermanagement/index'
import dailyprocess from '@/dailyprocess/index'
import report from '@/report/index'
import login from '@/login/index'
import register from '@/register/index'
import treemenu from '@/treemenu/index'

// import pos from '@/pos/index'
// import about from '@/about/index'
// import profile from '@/profile/index'
// import product from '@/product/index'

import { EventBus } from '@/misc/event-bus.js';

Vue.use(Router)

const guard = (to, from, next) => {
  if (localStorage.jwtToken) {
    next();
  } else {
    // Vue.toasted.show('').goAway(2000);
    // Vue.toasted.error('Please login before using this application!').goAway(2000);
    next({ path: '/login' });
  }

  console.log('[beforeEnter] The guard started! ');
};

const router = new Router({
  routes: [
    {
      path: '/',
      name: 'welcome',
      component: welcome,
      beforeEnter: guard
    },
     {
      path: '/treemenu',
      name: 'treemenu',
      component: treemenu
    },
    {
      path: '/home',
      name: 'home',
      component: home,
      beforeEnter: guard
    },
    {
      path: '/chequemanagement',
      name: 'chequemanagement',
      component: chequemanagement,
      beforeEnter: guard
    },
    {
      path: '/admin',
      name: 'admin',
      component: admin
    },
    {
      path: '/customermanagement',
      name: 'customermanagement',
      component: customermanagement,
      beforeEnter: guard
    },
    {
      path: '/dailyprocess',
      name: 'dailyprocess',
      component: dailyprocess,
      beforeEnter: guard
    },
    {
      path: '/report',
      name: 'report',
      component: report,
      beforeEnter: guard
    },
    {
      path: '/login',
      name: 'login',
      component: login
    },
    {
      path: '/register',
      name: 'register',
      component: register
    }
  ]
})
router.beforeEach((to, from, next) => {
  console.log('[beforeEach] started! ');
  next();

})

export default router;
