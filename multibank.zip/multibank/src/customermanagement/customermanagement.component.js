export default {
  name: 'customermanagement',
  components: {}, 
  props: [],
  data () {
    return {

    }
  },
  computed: {

  },
  mounted () {

  },
  methods: {

  }
}
