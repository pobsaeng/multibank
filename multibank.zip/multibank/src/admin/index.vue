<template src="./admin.component.html"></template>
<script src="./admin.component.js"></script>
<style src="./admin.component.scss" scoped lang="scss"></style>

