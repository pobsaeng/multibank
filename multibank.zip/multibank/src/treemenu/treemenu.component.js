import { EventBus } from '@/misc/event-bus.js';

export default {
  name: 'treemenu',
  components: {},
  props: [],
  data () {
    return {
      loggedIn: null
    }
  },
  computed: {

  },
  mounted () {
    EventBus.$on("loggedIn-checked", (status) => {
      this.loggedIn = status;
    });

  },
  methods: {

  }
}
