<template src="./treemenu.component.html"></template>
<script src="./treemenu.component.js"></script>
<style src="./treemenu.component.scss" scoped lang="scss"></style>

