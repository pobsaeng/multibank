import navbar from '@/components/navbar/index'
import axios from 'axios';

import {
  EventBus
} from '@/misc/event-bus.js';

export default {
  name: 'login',
  components: {},
  props: [],
  data() {
    return {}
  },
  computed: {

  },
  mounted() {

  },
  created() {},
  methods: {
    getAPI() {
      axios.post(`http://10.100.60.84:8529/MultibankService/api/auth`)
        .then(response => {
          console.log(response.data);
        })
        .catch(e => {
          this.errors.push(e)
        })

    },
    login() {
      const me = this;
      me.imageLoading = true;

      const path = this.SERVER_PATH + this.USER_VERBS.login;
      const params = {
        username: this.$refs.email.value.trim(),
        password: this.$refs.password.value.trim()
      }
      axios({
        method: 'post',
        url: path,
        headers: { 'Content-Type': 'application/json' },
        data: params

      }).then(function (response) {
        console.log("----------Success---------");
        console.log(response.data);

        localStorage.setItem('jwtToken', response.data.accessToken);
        EventBus.$emit('loggedIn-checked', true);
        me.imageLoading = false;
        me.$router.push('/dailyprocess');

      }).catch(error => {
        console.log("----------Error---------");
        console.log(error.response);
        me.imageLoading = false;
        me.$router.push('/login');
      });
    }
  }
}
