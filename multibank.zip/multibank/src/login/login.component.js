import navbar from '@/components/navbar/index'
import register from '@/register/index'

import {
  vueSlideoutPanelService
} from 'vue2-slideout-panel';
import axios from 'axios';

import {
  EventBus
} from '@/misc/event-bus.js';

export default {
  name: 'login',
  components: {},
  props: [],
  data() {
    return {
      email: '',
      password: '',
      errMsg: '',
      show: false,
      showModal: false
    }
  },
  computed: {
    isComplete() {
      return this.email && this.password;
    }
  },
  mounted() {},
  created() {},
  components: {
    register
  },
  methods: {
    loginSubmit() {
      const me = this;
      me.$validator.validateAll().then((result) => {
        console.log('result: ' + result);
        if (result) {
          me.doLogin();
          return;
        }
      });
    },
    getNameOfUser() {
      const me = this;
      const srvpath = this.SERVER_PATH + this.USER_VERBS.currentuser;
      const USER_TOKEN = localStorage.getItem("jwtToken");

      axios({
        method: 'post',
        url: srvpath,
        headers: {
          'Content-Type': 'application/json',
          "Authorization": "Bearer " + USER_TOKEN
        }
      }).then(function (response) {
        console.log("----------Success---------");
        me.$root.currentUser = response.data;
      }).catch(error => {
        console.log("----------Error---------");
        console.log(error.response.data);
      });

    },
    closeModal() {
      this.$modal.hide('register-modal');
    },
    onRegister() {
      this.$modal.show('register-modal');
    },
    doLogin() {
      const me = this;
      me.imageLoading = true;

      const dialog1 = {
        type: "warning",
        title: "Alert Message!",
        text: ""
      };

      // this.$swal({
      //   title: "Restore Image?",
      //   text: "You are about to restore this file. Are you sure you want to do this?",
      //   type: "success",
      //   showCancelButton: true,
      //   confirmButtonColor: "#00a65a",
      //   confirmButtonText: "Yes, restore it!",
      //   closeOnConfirm: true
      // });


      // const obj = {
      //   type: 'warning',
      //   title: 'Alert Message!',
      //   confirmButtonText: 'OK',
      //   text: '',
      //   confirmButtonColor: '#3085d6',
      //   showCloseButton: true,
      // }

      const path = this.SERVER_PATH + this.USER_VERBS.login;
      const params = {
        username: this.$refs.email.value.trim(),
        password: this.$refs.password.value.trim()
      }
      axios({
        method: 'post',
        url: path,
        headers: {
          'Content-Type': 'application/json'
        },
        data: params

      }).then(function (response) {
        console.log("----------Success---------");
        console.log(response.data);

        localStorage.setItem('jwtToken', response.data.accessToken);

        me.getNameOfUser();

        EventBus.$emit('loggedIn-checked', true);
        me.imageLoading = false;
        me.$router.push('/dailyprocess');

      }).catch(error => {
        console.log("----------Error---------");
        console.log(error.response.data);
        // me.errMsg = error.response.data.message;

        // me.$awn.options.msg = error.response.data.message
        // me.$awn.success()

        const errmsg = error.response.data.message;
        console.log(errmsg);

        if(errmsg == "Bad credentials"){
          dialog1.text = "Username or Password is incorrect!";
        }else{
          dialog1.text = error.response.data.message;
        }
        me.$swal(dialog1);

        me.imageLoading = false;
        me.$router.push('/login');
      });
    }
  }
}
