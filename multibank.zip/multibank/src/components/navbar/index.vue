<template src="./navbar.component.html"></template>
<script src="./navbar.component.js"></script>
<style src="./navbar.component.scss" scoped lang="scss"></style>

