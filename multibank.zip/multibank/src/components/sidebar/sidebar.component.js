import Vue from 'vue'
import $ from 'jquery'

export default {
  name: 'sidebar',
  components: {},
  props: ['nodes', 'label', 'depth'],
  data() {
    return {
      showChildren: false
    }
  },
  computed: {
    iconClasses() {
      return {
        'fa-plus-square-o': !this.showChildren,
        'fa-minus-square-o': this.showChildren
      }
    },
    labelClasses() {
      return {
        'has-children': this.nodes
      }
    },
    indent() {
      return {
        transform: `translate(${this.depth * 50}px)`
      }
    }
  },
  methods: {
    toggleChildren() {
      this.showChildren = !this.showChildren;
    }
  }
}
