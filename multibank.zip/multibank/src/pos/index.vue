<template src="./pos.component.html"></template>
<script src="./pos.component.js"></script>
<style src="./pos.component.scss" scoped lang="scss"></style>

