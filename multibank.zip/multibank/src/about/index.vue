<template src="./about.component.html"></template>
<script src="./about.component.js"></script>
<style src="./about.component.scss" scoped lang="scss"></style>

