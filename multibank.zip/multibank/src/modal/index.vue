<template src="./modal.component.html"></template>
<script src="./modal.component.js"></script>
<style src="./modal.component.scss" scoped lang="scss"></style>

