package com.company.app;

import com.company.dao.StockDao;
import com.company.entity.Stock;
import com.company.entity.StockDetail;
import java.util.Date;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App {

    public static void main(String[] args) {
//        System.out.println("Hibernate one to one (Annotation)");
//        
//        Stock stock = new Stock();
//        stock.setStockCode("123");
//        stock.setStockName("123");
//        
//        StockDetail stockDetail = new StockDetail();
//        stockDetail.setCompDesc("234");
//        stockDetail.setCompName("3141");
//        stockDetail.setRemark("24324");
//        stockDetail.setListedDate(new Date());
//        stockDetail.setStock(stock);
        
//        stock.setStockDetail(stockDetail);
        StockDao stockDao = new StockDao();
//        
//        System.out.println("***************************Insert*************************");
//        stockDao.insertCascade(stock);
//        System.out.println("Insert : "+stockDao.findById(stock.getStockId()));
//        
//        System.out.println("***************************Update*************************");
//        stockDao.updateCascade(stock);
//        System.out.println("Update : "+stockDao.findById(stock.getStockId()));
//        
//        System.out.println("***************************Delete*************************");
//        stockDao.deleteCascade(stock.getStockId());
//        System.out.println("Delete done!!");
       List list = stockDao.listViewCriteria();
        for (Object object : list) {
            System.out.println("Result: " + object);
        }
    }
}
