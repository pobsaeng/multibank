import { withParams, req } from './common'
export default withParams({ type: 'required' }, req)
