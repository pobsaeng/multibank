import { regex } from './common'
export default regex('integer', /^-?[0-9]*$/)
