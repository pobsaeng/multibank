import { regex } from './common'
export default regex('numeric', /^[0-9]*$/)
