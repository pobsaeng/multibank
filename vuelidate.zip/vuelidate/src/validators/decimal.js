import { regex } from './common'
export default regex('decimal', /^[-]?\d*(\.\d+)?$/)
