import { regex } from './common'
export default regex('alphaNum', /^[a-zA-Z0-9]*$/)
