<template>
<div class="row">
  <div class="col-md-12">
    <div class="box box-bay">
      <div class="box-header">
        <h3 class="box-title">Cheque Page.</h3>
      </div>
      <div class="box-body">

      </div>
    </div>
  </div>
</div> 
</template>

<script>
export default {
  name: "cheque",
  data() {
    return {};
  }
};
</script>