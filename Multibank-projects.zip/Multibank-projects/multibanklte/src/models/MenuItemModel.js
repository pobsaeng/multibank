module.exports = {
  type: "",
  icon: "",
  name: "",
  items: []
}
