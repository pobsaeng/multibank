package com.multibank.config;

public interface EnvBasedCofig {
 void setup();
}
