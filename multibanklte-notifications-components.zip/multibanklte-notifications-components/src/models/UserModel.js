module.exports = {
    username: "",
    password: "",
    password_retype: "",
    fullname: "",
    email: "",
    menu_items: {}
  };
  