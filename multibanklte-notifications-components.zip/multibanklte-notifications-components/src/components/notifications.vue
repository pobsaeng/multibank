<template>
    <div id="notifications">
        <div>
            <div id="add-remove-modal" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div v-bind:class="['box-header', 'with-border', 'alert alert-'+className]">
                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true" @click="closeModal">×</span><span class="sr-only" @click="closeModal">close</span></button>
                            <h4 class="modal-title">Delete Holiday</h4>
                        </div>
                        <div id="modalBody" class="modal-body">
                            <div style="color:black;">{{message}}</div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" @click="closeModal" data-dismiss="modal">No</button>
                              <button class="btn btn-danger" data-dismiss="modal">Yes</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
  data() {
    return {
        message: '',
        className: ''
    };
  },
  created() {
    this.$watch('notifications', (noti) => {
        
      if(noti.status){
          this.message = noti.message;
          this.className = noti.className;
        $("#add-remove-modal").modal({ backdrop: "static", keyboard: false });
      }else{
        this.closeModal();
      }
    })
  },
  methods: {
    closeModal() {
      this.$emit("MODAL_STATUS", false);
    }
  },

  props: ["notifications"]
};
</script>
