package com.vue.spb.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.websocket.server.PathParam;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.vue.spb.request.UserRegistration;
import com.vue.spb.response.InputLanguageForm;


@RestController
public class UserController {
	List<InputLanguageForm> listOfInputLang = new ArrayList<InputLanguageForm>();
	
	@PostConstruct
	public void initIt() throws Exception {
		initData();
	}
	
	@GetMapping(value = "/")
	public ModelAndView register(ModelAndView mav) {
		mav.setViewName("formsubmit");
		return mav;
	}
	
	@GetMapping(value = "/loginForm")
	public ModelAndView loginForm(ModelAndView mav) {
		System.out.println("loginForm!");
		mav.setViewName("login");
		return mav;
	}

	@PostMapping(value = "/save")
	public ModelAndView save(@RequestBody InputLanguageForm inputLanguageForm) {
		inputLanguageForm.setId("" + (listOfInputLang.size() + 1));
		listOfInputLang.add(inputLanguageForm);
		return new ModelAndView("redirect:/findAll");
	}
	
	@PostMapping(value = "/update")
	public ModelAndView update(@RequestBody InputLanguageForm inputLanguageForm) {
		System.out.println(inputLanguageForm);
		
		Iterator<InputLanguageForm> iter = listOfInputLang.iterator();
		while (iter.hasNext()) {
			InputLanguageForm inputLang = iter.next();			
			if(inputLang.getId().equalsIgnoreCase(inputLanguageForm.getId())) {
				iter.remove();
			}
		}
		
		listOfInputLang.add(inputLanguageForm);
		return new ModelAndView("redirect:/findAll");
	}
	
	@GetMapping(value = "/delete/{id}")
	public ModelAndView remove(@PathVariable String id) {
		Iterator<InputLanguageForm> iter = listOfInputLang.iterator();
		while (iter.hasNext()) {
			InputLanguageForm inputLang = iter.next();			
			if(inputLang.getId().equalsIgnoreCase(id)) {
				iter.remove();
			}
		}
		return new ModelAndView("redirect:/findAll");
	}

	@GetMapping(value = "/findAll")
	public List<InputLanguageForm> posts() {
		System.out.println("findAll!");
		return listOfInputLang;
	}
	
	@GetMapping(value = "/load")
	public List<InputLanguageForm> loadData() {
		initData();
		return listOfInputLang;
	}
	
	private void initData(){
		System.out.println("Initializing data!");
		InputLanguageForm inputLang1 = new InputLanguageForm();
		inputLang1.setId("1");
		inputLang1.setInputLang("Java 8");
		inputLang1.setSelectsLevel("Low");
		inputLang1.setRemark("I have just learned it");
		
		InputLanguageForm inputLang2 = new InputLanguageForm();
		inputLang2.setId("2");
		inputLang2.setInputLang("Vue 2.0");
		inputLang2.setSelectsLevel("High");
		inputLang2.setRemark("I have been working for 2 years");
		
		InputLanguageForm inputLang3 = new InputLanguageForm();
		inputLang3.setId("3");
		inputLang3.setInputLang("Spring Boot");
		inputLang3.setSelectsLevel("Advance");
		inputLang3.setRemark("I have experience for 6 years");
		
		InputLanguageForm inputLang4 = new InputLanguageForm();
		inputLang4.setId("4");
		inputLang4.setInputLang("Python");
		inputLang4.setSelectsLevel("Advance");
		inputLang4.setRemark("I have experience for 10 years");
				
		listOfInputLang.add(inputLang1);
		listOfInputLang.add(inputLang2);
		listOfInputLang.add(inputLang3);
		listOfInputLang.add(inputLang4);
	}

}
