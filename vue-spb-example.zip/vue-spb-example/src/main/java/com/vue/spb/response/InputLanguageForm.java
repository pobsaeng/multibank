package com.vue.spb.response;

public class InputLanguageForm {
	private String id;
	private String inputLang;
	private String selectsLevel;
	private String remark;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getInputLang() {
		return inputLang;
	}
	public void setInputLang(String inputLang) {
		this.inputLang = inputLang;
	}
	public String getSelectsLevel() {
		return selectsLevel;
	}
	public void setSelectsLevel(String selectsLevel) {
		this.selectsLevel = selectsLevel;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return "InputLanguageForm [id=" + id + ", inputLang=" + inputLang + ", selectsLevel=" + selectsLevel
				+ ", remark=" + remark + "]";
	}
}
