//var MyComponent = Vue.extend({
//  template: '<div>A custom component!</div>'
//})
//
//Vue.component('my-component', MyComponent)

window.Event = new Vue({});

Vue.component('table-component', {
    template: 
	` 
	<div class="col-lg-8 mx-auto">
		<table class="table table-sm">
	    <thead>
	      <tr>
	        <th>Languages</th>
	        <th>Levels</th>
	        <th>Remark</th>
	        <th>&#174;</th>
	      </tr>
	    </thead>
	    
	    <tbody>
	      <tr v-for="item in listContent">
	        <td>{{item.inputLang}}</td>
	        <td>{{item.selectsLevel}}</td>
	        <td>{{item.remark}}</td>
    		<td>
    		<button type="button" v-on:click="edit(item)" data-toggle="modal" data-target="#formModal" class="btn btn-sm btn-success btnTable">Edit</button>
			<button type="button" v-on:click="remove(item.id)" class="btn btn-sm btn-warning btnTable">Delete</button>
			<form-modal :listEdit="listedit"></form-modal>
    		</td>
	      </tr>
	    </tbody>
	    
	  </table>
    </div>
	`,
	 data: function(){
        return {
        	listedit: {},
        	listContent: []
        }
    },
    created(){
    	console.log("--created--");
    	const me = this;
    	
    	// For binding to a form
    	Event.$on("list-form-bind", (emp) => {
    		if(emp.action == "add") me.listedit = {};
	    });
    	// For updating data a table
    	Event.$on("list-content", (values) => {
    		me.listContent = values;
  	    });
    	
    },
     mounted(){
    	console.log("--table--");
    },
    methods: {
    	edit(item){
    		this.listedit = Object.assign({}, item);
    	},
    	remove(id){
    		const me = this;
    		axios.get("/delete/" + id).then(function(response){
             	me.listContent = response.data;
             });
    	}
    }
});