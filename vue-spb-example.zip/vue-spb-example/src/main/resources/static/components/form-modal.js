window.Event = new Vue({});

Vue.component('form-modal', {
	props: ['listEdit'],
    template: 
	`
	<div class="col mx-auto">
	 <div class="modal fade" id="formModal" tabindex="-1" role="dialog" aria-labelledby="formModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
        	<h4 class="modal-title">Modal</h4>
        	<button type="button" class="close" data-dismiss="modal">&times;</button>
    	</div>
          <div class="modal-body">      
            <div class="col mx-auto">
				<div class="row">
					<div class="col-7">
						<label>Input Language</label>
						<div class="form-group input-group">
							<span class="input-group-addon">&#9924;</span>
							<input type="text" class="form-contro" v-model="listEdit.inputLang" placeholder="">
						</div>
					</div>
					<div class="col-5">
						<div class="form-group">
							<label>Selects Level</label>
							<select v-model="listEdit.selectsLevel" :value="listEdit.selectsLevel" class="form-control">
								<option>Low</option>
								<option>High</option>
								<option>Advance</option>
								<option>Proficient</option>
							</select>
						</div>
					</div>
				</div>
	
				<fieldset class="form-group">
					<label>Remark</label>
					<textarea v-model="listEdit.remark" class="form-control" rows="3"></textarea>
				</fieldset>
	
			</div>
				
           </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="button" v-on:click="save" class="btn btn-primary" data-dismiss="modal">Save</button>
          </div>
        </div>
      </div>
    </div>   
    </div>  
	`,
	 data: function(){
        return {
        	action: ""
        }
    },
    created(){
    	// For binding to a form
    	Event.$on("list-form-bind", (emp) => {
    		if(emp.action == "add"){
    			console.log(emp.action);
    			this.action = emp.action;
    		}else{
    			this.action = "update";
    		}
	    });
    },
     methods: {
         save(){
        	 const me = this;
        	 if(this.action == "add"){
        		 me.listEdit.id = "";
        		 axios({
     	    	    method: 'post',
     	    	    url: '/save',
     	    	    data: this.listEdit,
     	    	    config: { headers: {"Content-type": "application/json; charset=utf-8"}}
     	    	    }).then(function (response) {
     	    	        Event.$emit('list-content', response.data);
     	    	        
     	    	    }).catch(function (response) {
         	        console.log(response);
         	    });
        		 
        	 }else{
        		 axios({
      	    	    method: 'post',
      	    	    url: '/update',
      	    	    data: this.listEdit,
      	    	    config: { headers: {"Content-type": "application/json; charset=utf-8"}}
      	    	    }).then(function (response) {
      	    	    	console.log(response.data);
      	    	        Event.$emit('list-content', response.data);
      	    	        
      	    	    }).catch(function (response) {
          	        console.log(response);
          	    });
        	 }
             
         }
     },
});