package com.multibank.repositories;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.multibank.model.Book;

public interface BookRepository extends JpaRepository<Book, Long> {

	@Query(value = "SELECT * FROM book", nativeQuery = true)
	List<Book> findAllBook();

	@Query(value = "SELECT * FROM book where id=?", nativeQuery = true)
	List<Book> findBookById(Integer id);

	@Query(value = "SELECT u FROM Book u")
	List<Book> findAllBookWithJPQL(Sort sort);

	@Query("SELECT u FROM Book u WHERE u.id = ?1")
	Book findBookByIdWithJPQL(Integer number);

	@Query("SELECT u FROM Book u WHERE u.stock = :stock and u.price = :price")
	List<Book> findBookByIdAndPriceParams(@Param("stock") Integer stock, @Param("price") Integer price);

	@Query(value = "update Book u set u.title = ? where u.id = ?")
	int updateBookForNameNative(String title, Integer id);
}
