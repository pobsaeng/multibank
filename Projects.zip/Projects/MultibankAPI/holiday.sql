﻿# HeidiSQL Dump 
#
# --------------------------------------------------------
# Host:                         10.100.60.178
# Database:                     multibank
# Server version:               5.6.22-log
# Server OS:                    Win64
# Target compatibility:         ANSI SQL
# HeidiSQL version:             4.0
# Date/time:                    2018-08-30 18:03:34
# --------------------------------------------------------

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI,NO_BACKSLASH_ESCAPES';*/
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;*/


#
# Database structure for database 'multibank'
#

CREATE DATABASE /*!32312 IF NOT EXISTS*/ "multibank" /*!40100 DEFAULT CHARACTER SET utf8 */;

USE "multibank";


#
# Table structure for table 'holiday'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "holiday" (
  "holiday_id" bigint(20) NOT NULL AUTO_INCREMENT,
  "holiday_name" varchar(200) DEFAULT NULL,
  "holiday_date" timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("holiday_id")
) AUTO_INCREMENT=25;



#
# Dumping data for table 'holiday'
#

LOCK TABLES "holiday" WRITE;
/*!40000 ALTER TABLE "holiday" DISABLE KEYS;*/
REPLACE INTO "holiday" ("holiday_id", "holiday_name", "holiday_date") VALUES
	('19','Test 1','2018-08-01 07:00:00');
REPLACE INTO "holiday" ("holiday_id", "holiday_name", "holiday_date") VALUES
	('20','Test 2','2018-08-02 07:00:00');
REPLACE INTO "holiday" ("holiday_id", "holiday_name", "holiday_date") VALUES
	('21','Test 3','2018-08-03 07:00:00');
REPLACE INTO "holiday" ("holiday_id", "holiday_name", "holiday_date") VALUES
	('22','Test 4','2018-08-04 07:00:00');
REPLACE INTO "holiday" ("holiday_id", "holiday_name", "holiday_date") VALUES
	('23','Test 11','2018-08-01 07:00:00');
REPLACE INTO "holiday" ("holiday_id", "holiday_name", "holiday_date") VALUES
	('24','Test 101','2018-08-01 07:00:00');
/*!40000 ALTER TABLE "holiday" ENABLE KEYS;*/
UNLOCK TABLES;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE;*/
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;*/
